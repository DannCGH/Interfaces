import java.util.Arrays;

public class Author implements Comparable<Author> {
    private String firstName, lastName, bookTitle;

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    Author(String firstName, String lastName, String bookTitle){
        setFirstName(firstName);
        setLastName(lastName);
        setBookTitle(bookTitle);
    }

    public int compareTo(Author o) {
        String[] comparingStrings = new String[2];
        if (o.lastName.equals(lastName)) {
            if (o.firstName.equals(firstName)) {
                comparingStrings[0] = (bookTitle);
                comparingStrings[1] = (o.bookTitle);
                Arrays.sort(comparingStrings);
                if (comparingStrings[0].equals(bookTitle)) {
                    return 1;
                } else if (comparingStrings[0].equals(o.bookTitle)) {
                    return -1;
                } else {
                    return 0;
                }
            } else {
                comparingStrings[0] = (firstName);
                comparingStrings[1] = (o.firstName);
                Arrays.sort(comparingStrings);
                if (comparingStrings[0].equals(firstName)) {
                    return 1;
                } else if (comparingStrings[0].equals(o.firstName)) {
                    return -1;
                } else {
                    return 0;
                }
            }
        } else {
            comparingStrings[0] = (lastName);
            comparingStrings[1] = (o.lastName);
            Arrays.sort(comparingStrings);
            if (comparingStrings[0].equals(lastName)) {
                return 1;
            } else if (comparingStrings[0].equals(o.lastName)) {
                return -1;
            } else {
                return 0;
            }
        }
    }

}

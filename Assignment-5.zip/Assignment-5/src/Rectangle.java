public class Rectangle implements Shape {
    private double height;
    private double width;

    public double getHeight() {
        return height;
    }

    public double getWidth() {
        return width;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    Rectangle(double height, double width){
        setHeight(height);
        setWidth(width);
    }

    public double area() {
        return (height * width);
    }
}

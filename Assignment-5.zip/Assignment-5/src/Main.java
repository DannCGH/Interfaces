public class Main {
    public static void main(String[] args) {
        Circle c = new Circle(4);
        Rectangle r = new Rectangle(4, 3);
        ShowArea(c);
        ShowArea(r);

        System.out.println();

        String[] authorsFirstNames = {"Henry", "Nalo", "Frank", "Deborah", "George R. R."};
        String[] authorsLastNames = {"Miller", "Hopkinson", "Miller", "Hopkinson", "Martin"};
        String[] authorsBooks = {"Tropic of Cancer", "Brown Girl in the Ring", "300", "Sky Boys", "Song of Ice and Fire"};


        Author[] author = new Author[5];
        for (int i = 0; i < author.length; i++){
            author[i] = new Author(authorsFirstNames[i], authorsLastNames[i], authorsBooks[i]);
            System.out.println(author[i].getFirstName() + ", "
                    + author[i].getLastName() + "; "
                    + author[i].getBookTitle());
        }

        System.out.println();
        System.out.println("*** After Sorting ***");
        System.out.println();

        Author temp;
        for (int i = 0; i < author.length - 1; i++) {
            for (int j = 1; j < author.length; j++) {
                if(author[j] != null && author[j-1] != null && (author[j].compareTo(author[j-1]) > 0)){
                    temp = author[j];
                    author[j] = author[j-1];
                    author[j-1] = temp;
                }
            }
        }

        for (int i = 0; i < author.length; i++){
            System.out.println(author[i].getFirstName() + ", "
                    + author[i].getLastName() + "; "
                    + author[i].getBookTitle());
        }

    }
    public static void ShowArea(Shape s){
        double area = s.area();
        System.out.println("The area of the shape is " + area);
    }
}
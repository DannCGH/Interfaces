public class Circle implements Shape {

    private double radius;

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    Circle(double radius){
        setRadius(radius);
    }

    public double area() {
        return ((radius * radius) * 3.14159);
    }
}
